#Written on Visual Studio 2022

from winsound import PlaySound
from playsound import playsound


def mergeSort(array):
    if len(array) > 1:

        Split = len(array)//2
        L = array[:Split]
        print("Left side subarray: ")
        print(L)
        R = array[Split:]
        print("Right side subarray: ")
        print(R)

        mergeSort(L)
        mergeSort(R)

        i = j = k = 0

        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                array[k] = L[i]
                i += 1
                playsound('Boop.wav')
                print("Sound played")
                printList(array)
            else:
                array[k] = R[j]
                playsound('Boop.wav')
                print("Sound played")
                printList(array)
                j += 1
            k += 1

        while i < len(L):
            array[k] = L[i]
            playsound('Boop.wav')
            print("Sound played")
            printList(array)
            i += 1
            k += 1

        while j < len(R):
            array[k] = R[j]
            playsound('Boop.wav')
            print("Sound played")
            printList(array)
            j += 1
            k += 1


def printList(array):
    for i in range(len(array)):
        print(array[i], end=" ")
    print()


if __name__ == '__main__':

    i = 0
    array = []
    arrayLength = int(input("Enter how long you want your array to be: "))
    while (i < arrayLength):
        arrayInput = int(input("Enter your number into the array: "))
        array.append(arrayInput)
        print(f"Added {arrayInput} to the array")
        i += 1

    print("Current array is: ")
    printList(array)
    
    mergeSort(array)
    
    print("Sorted array is: ")
    printList(array)
